/*
   Copyright 2015-2019 Kai Huebl (kai@huebl-sgh.de)

   Lizenziert gemäß Apache Licence Version 2.0 (die „Lizenz“); Nutzung dieser
   Datei nur in Übereinstimmung mit der Lizenz erlaubt.
   Eine Kopie der Lizenz erhalten Sie auf http://www.apache.org/licenses/LICENSE-2.0.

   Sofern nicht gemäß geltendem Recht vorgeschrieben oder schriftlich vereinbart,
   erfolgt die Bereitstellung der im Rahmen der Lizenz verbreiteten Software OHNE
   GEWÄHR ODER VORBEHALTE – ganz gleich, ob ausdrücklich oder stillschweigend.

   Informationen über die jeweiligen Bedingungen für Genehmigungen und Einschränkungen
   im Rahmen der Lizenz finden Sie in der Lizenz.

   Autor: Kai Huebl (kai@huebl-sgh.de), Aleksey Timin (atimin@gmail.com)
 */

#include "OpcUaStackCore/Base/os.h"
#include "OpcUaStackCore/Base/Log.h"
#include "data_access/Library/Library.h"
#include "OpcUaStackServer/ServiceSetApplication/ApplicationService.h"
#include "OpcUaStackServer/ServiceSetApplication/NodeReferenceApplication.h"
#include "OpcUaStackServer/ServiceSetApplication/CreateNodeInstance.h"
#include "OpcUaStackServer/ServiceSetApplication/DeleteNodeInstance.h"
#include "OpcUaStackServer/ServiceSetApplication/GetNodeReference.h"
#include "OpcUaStackServer/ServiceSetApplication/RegisterForwardNode.h"
#include <iostream>
#include "BuildConfig.h"

namespace data_access {

Library::Library(void)
    : ApplicationIf(), sourceValue_(0) {
}

Library::~Library(void) {
}

bool
Library::startup(void) {
    Log(Debug, "Library::startup");

    CreateNodeInstance createNodeInstance(
        "DynamicVariable",                            // name
        NodeClass::Enum::EnumVariable,          // node class
        OpcUaNodeId(85),                              // parent node id (Objects)
        OpcUaNodeId("Dynamic", 1),                    // node id
        OpcUaLocalizedText("en", "DynamicVariable"),  // display name
        OpcUaQualifiedName("DynamicVariable", 1),     // browse name
        OpcUaNodeId(47),                              // reference type id
        OpcUaNodeId(62)                               // type node id
    );

    if (!createNodeInstance.query(&this->service())) {
        std::cout << "createNodeInstance response error" << std::endl;
    }

    RegisterForwardNode registerForwardNode;

    registerForwardNode.setReadCallback(boost::bind(&Library::readValue, this, _1));
    registerForwardNode.setWriteCallback(boost::bind(&Library::writeValue, this, _1));
    registerForwardNode.setMonitoredItemStartCallback(boost::bind(&Library::startMonitoredItems, this, _1));
    registerForwardNode.setMonitoredItemStopCallback(boost::bind(&Library::stopMonitoredItems, this, _1));

    registerForwardNode.addNode(OpcUaNodeId(203, 1));

    if (!registerForwardNode.query(&this->service())) {
        Log(Error, "registerForwardNode response error");
        return false;
    }

    return true;
}

bool
Library::shutdown(void) {
    Log(Debug, "Library::shutdown");

    DeleteNodeInstance deleteNodeInstance(OpcUaNodeId("Dynamic", 1));

    if (!deleteNodeInstance.query(&this->service())) {
        std::cout << "deleteNodeInstance response error" << std::endl;
        return false;
    }

    return true;
}

std::string
Library::version(void) {
    std::stringstream version;

    version << LIBRARY_VERSION_MAJOR << "." << LIBRARY_VERSION_MINOR << "." << LIBRARY_VERSION_PATCH;
    return version.str();
}

void
Library::readValue(ApplicationReadContext *context) {
    Log(Info, "Read data from node")
        .parameter("nodeId", context->nodeId_)
        .parameter("attributeId", context->attributeId_);

    context->statusCode_ = OpcUaStatusCode::Success;

    if (context->attributeId_ == AttributeId::AttributeId_Value) {
        context->dataValue_.copyFrom(sourceValue_);
    }
}

void
Library::writeValue(ApplicationWriteContext *context) {
    Log(Info, "Write data to node")
        .parameter("nodeId", context->nodeId_)
        .parameter("attributeId", context->attributeId_);

    context->statusCode_ = OpcUaStatusCode::Success;

    if (context->attributeId_ == AttributeId::AttributeId_Value) {
        context->dataValue_.copyTo(sourceValue_);
    }
}

void
Library::startMonitoredItems(ApplicationMonitoredItemStartContext *context) {
    Log(Info, "Start monitoring.")
        .parameter("nodeId", context->nodeId_);
}

void
Library::stopMonitoredItems(ApplicationMonitoredItemStopContext *context) {
    Log(Info, "Stop monitoring.")
        .parameter("nodeId", context->nodeId_);
}

}

extern "C" DLLEXPORT void init(ApplicationIf **applicationIf) {
    *applicationIf = new data_access::Library();
}

