data_access
========================================================

Installation
--------------------------------------------------------

In order to install data_access in your machine type the following command:

**On Linux** 

::
    $ sh build.sh -t local
	 
	
**On Windows**

::
    $ build.bat local


Docker
--------------------------------------------------------

You can use Docker to run data_access:

::
    $ docker build -t data_access:latest .
    $ docker run -d -p 9001:9001 data_access:latest
