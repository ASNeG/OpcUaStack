/*
   Copyright 2015-2017 Kai Huebl (kai@huebl-sgh.de)

   Lizenziert gemäß Apache Licence Version 2.0 (die „Lizenz“); Nutzung dieser
   Datei nur in Übereinstimmung mit der Lizenz erlaubt.
   Eine Kopie der Lizenz erhalten Sie auf http://www.apache.org/licenses/LICENSE-2.0.

   Sofern nicht gemäß geltendem Recht vorgeschrieben oder schriftlich vereinbart,
   erfolgt die Bereitstellung der im Rahmen der Lizenz verbreiteten Software OHNE
   GEWÄHR ODER VORBEHALTE – ganz gleich, ob ausdrücklich oder stillschweigend.

   Informationen über die jeweiligen Bedingungen für Genehmigungen und Einschränkungen
   im Rahmen der Lizenz finden Sie in der Lizenz.

   Autor: Kai Huebl (kai@huebl-sgh.de)
 */

#include "OpcUaStackCore/Base/os.h"
#include "OpcUaStackCore/Base/Log.h"
#include "testApp/Library/Library.h"
#include "OpcUaStackServer/ServiceSetApplication/ApplicationService.h"
#include "OpcUaStackServer/ServiceSetApplication/NodeReferenceApplication.h"
#include "OpcUaStackServer/ServiceSetApplication/RegisterForwardGlobal.h"
#include <iostream>
#include "BuildConfig.h"

#include "OpcUaStackCore/ServiceSet/UserNameIdentityToken.h"

namespace testApp
{

	Library::Library(void)
	: ApplicationIf()
	{
	}

	Library::~Library(void)
	{
	}

	bool
	Library::startup(void)
	{
	    RegisterForwardGlobal registerForwardGlobal;
	    registerForwardGlobal.setAuthenticationCallback(boost::bind(&Library::authenticationCallback, this, _1));
	    registerForwardGlobal.setAutorizationCallback(boost::bind(&Library::autorizationCallback, this, _1));
	    registerForwardGlobal.setCloseSessionCallback(boost::bind(&Library::closeSessionCallback, this, _1));
	    if (!registerForwardGlobal.query(&this->service())) {
	    	std::cout << "registerForwardGlobal response error" << std::endl;
	    	return false;
	    }

	    userMap_ = UserProfile::Map();
	    userMap_["User_RW"] = constructSPtr<UserProfile>("User_RW", "password1", "rw");
	    userMap_["User_R"] = constructSPtr<UserProfile>("User_R", "password2", "r");

	    return true;
	}

	bool
	Library::shutdown(void)
	{
		Log(Debug, "Library::shutdown");
		return true;
	}

	std::string
	Library::version(void)
	{
		std::stringstream version;

		version << LIBRARY_VERSION_MAJOR << "." << LIBRARY_VERSION_MINOR << "." << LIBRARY_VERSION_PATCH;
		return version.str();
	}

	void
	Library::authenticationCallback(
			ApplicationAuthenticationContext* contex)
	{
		Log(Debug, "Event::authenticationCallback")
			.parameter("SessionId", contex->sessionId_);


		if (contex->authenticationType_ == OpcUaId_AnonymousIdentityToken_Encoding_DefaultBinary) {
			contex->statusCode_ = BadIdentityTokenRejected;
		}
		else if (contex->authenticationType_ == OpcUaId_UserNameIdentityToken_Encoding_DefaultBinary) {

			ExtensibleParameter::SPtr parameter = contex->parameter_;
			UserNameIdentityToken::SPtr token = parameter->parameter<UserNameIdentityToken>();

			// find user profile
			UserProfile::Map::iterator it;
			it = userMap_.find(token->userName());
			if (it == userMap_.end()) {
				contex->statusCode_ = BadUserAccessDenied;
				return;
			}

			UserProfile::SPtr userProfile = it->second;

			// check password
			if (token->password() != userProfile->password_) {
				contex->statusCode_ = BadUserAccessDenied;
				return;
			}

			contex->userContext_ = userProfile;
			contex->statusCode_ = Success;
		}
		else if (contex->authenticationType_ == OpcUaId_X509IdentityToken_Encoding_DefaultBinary) {
			contex->statusCode_ = BadIdentityTokenRejected;
		}
		else {
			contex->statusCode_ = BadIdentityTokenInvalid;
		}
	}

	void
	Library::closeSessionCallback(
			ApplicationCloseSessionContext* context)
	{
		if (!context->userContext_) {
			context->statusCode_ = BadUserAccessDenied;
			return;
		}

		auto user = boost::dynamic_pointer_cast<UserProfile>(context->userContext_);

		Log(Info, "User close the session.")
			.parameter("Username", user->username_)
			.parameter("SessionId", context->sessionId_);

	}

	void
	Library::autorizationCallback(
			ApplicationAutorizationContext* context)
	{
		if (!context->userContext_) {
			context->statusCode_ = BadUserAccessDenied;
			return;
		}

		auto user = boost::dynamic_pointer_cast<UserProfile>(context->userContext_);

		bool allowed = false;
		switch (context->serviceOperation_) {
			case ServiceOperation::Read:
			case ServiceOperation::MonitoredItem:
				allowed = user->access_ == "r" || user->access_ == "rw";
				break;
			case ServiceOperation::Write:
				allowed = user->access_ == "rw";
				break;
			default:
				break;
		}

		context->statusCode_ = allowed ? Success : BadUserAccessDenied;
	}

}

extern "C" DLLEXPORT void  init(ApplicationIf** applicationIf) {
    *applicationIf = new testApp::Library();
}

