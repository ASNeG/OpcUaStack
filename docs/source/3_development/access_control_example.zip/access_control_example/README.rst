testApp
========================================================

Installation
--------------------------------------------------------

In order to install testApp in your machine type the following command:

**On Linux** 

::
    $ sh build.sh -t local
	 
	
**On Windows**

::
    $ build.bat local


Docker
--------------------------------------------------------

You can use Docker to run testApp:

::
    $ docker build -t testApp:latest .
    $ docker run -d -p 9000:9000 testApp:latest
