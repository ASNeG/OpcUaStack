/*
   Copyright 2015-2017 Kai Huebl (kai@huebl-sgh.de)

   Lizenziert gemäß Apache Licence Version 2.0 (die „Lizenz“); Nutzung dieser
   Datei nur in Übereinstimmung mit der Lizenz erlaubt.
   Eine Kopie der Lizenz erhalten Sie auf http://www.apache.org/licenses/LICENSE-2.0.

   Sofern nicht gemäß geltendem Recht vorgeschrieben oder schriftlich vereinbart,
   erfolgt die Bereitstellung der im Rahmen der Lizenz verbreiteten Software OHNE
   GEWÄHR ODER VORBEHALTE – ganz gleich, ob ausdrücklich oder stillschweigend.

   Informationen über die jeweiligen Bedingungen für Genehmigungen und Einschränkungen
   im Rahmen der Lizenz finden Sie in der Lizenz.

   Autor: Kai Huebl (kai@huebl-sgh.de)
 */

#ifndef __testApp_Library_h__
#define __testApp_Library_h__

#include "OpcUaStackServer/Application/ApplicationIf.h"
#include "OpcUaStackCore/Application/ApplicationAuthenticationContext.h"
#include "OpcUaStackCore/Application/ApplicationAutorizationContext.h"
#include "OpcUaStackCore/Application/ApplicationCloseSessionContext.h"

using namespace OpcUaStackCore;
using namespace OpcUaStackServer;

namespace testApp
{
	class UserProfile : public UserContext {
	public:
		typedef boost::shared_ptr<UserProfile> SPtr;
		typedef std::map<std::string, UserProfile::SPtr> Map;
		UserProfile(std::string username, std::string password, std::string access)
			: username_(username)
			, password_(password)
			, access_(access)
		{

		}

		std::string username_;
		std::string password_;
		std::string access_;
	};

	class Library
	: public ApplicationIf
	{
	  public:
		Library(void);
		virtual ~Library(void);

		//- ApplicationIf -----------------------------------------------------
		virtual bool startup(void);
		virtual bool shutdown(void);
		virtual std::string version(void);
		//- ApplicationIf -----------------------------------------------------

	  private:
	    void authenticationCallback(ApplicationAuthenticationContext* context);
	    void closeSessionCallback(ApplicationCloseSessionContext* context);
	    void autorizationCallback(ApplicationAutorizationContext* context);

	    UserProfile::Map userMap_;
	};

}

#endif
