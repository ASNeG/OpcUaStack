helloworld
========================================================

Installation
--------------------------------------------------------

In order to install helloworld in your machine type the following command:

**On Linux** 

::
    $ sh build.sh -t local
	 
	
**On Windows**

::
    $ build.bat local


Docker
--------------------------------------------------------

You can use Docker to run helloworld:

::
    $ docker build -t helloworld:latest .
    $ docker run -d -p 8888:8888 helloworld:latest
